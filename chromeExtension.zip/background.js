chrome.browserAction.onClicked.addListener(function() {
    chrome.tabs.create({'url': "http://www.uni-potsdam.de/u/zeik/psn/studheim-sdg"});
});
